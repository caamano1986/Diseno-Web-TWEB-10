// Transiciones fotográficas automáticas
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar transición para galería
    const galeriaItems = document.querySelectorAll('.galeria-item');
    
    // Asignar retrasos diferentes a cada elemento para animación escalonada
    galeriaItems.forEach((item, index) => {
        const img = item.querySelector('img');
        if (img) {
            // Retraso escalonado para efecto Ken Burns
            img.style.animationDelay = `${index * 2}s`;
        }
    });
    
    // Iniciar transiciones para testimonios
    const testimonios = document.querySelectorAll('.testimonio');
    testimonios.forEach((testimonio, index) => {
        // Añadir clase para efecto de entrada escalonado
        setTimeout(() => {
            testimonio.classList.add('testimonio-visible');
        }, 300 * index);
    });
    
    // Efecto de desvanecimiento entre imágenes
    let currentIndex = 0;
    const totalImages = galeriaItems.length;
    
    function crossfadeImages() {
        // Ocultar imagen actual
        galeriaItems[currentIndex].style.opacity = '0.8';
        
        // Actualizar índice
        currentIndex = (currentIndex + 1) % totalImages;
        
        // Mostrar siguiente imagen
        galeriaItems[currentIndex].style.opacity = '1';
        
        // Añadir destello visual
        galeriaItems[currentIndex].classList.add('image-highlight');
        
        // Eliminar destello después de la transición
        setTimeout(() => {
            galeriaItems[currentIndex].classList.remove('image-highlight');
        }, 1000);
    }
    
    // Desactivar transición auto cuando el mouse está sobre la galería
    const galeriaSection = document.getElementById('galeria');
    let transitionPaused = false;
    let transitionInterval;
    
    function startTransition() {
        transitionInterval = setInterval(crossfadeImages, 5000);
    }
    
    galeriaSection.addEventListener('mouseenter', () => {
        clearInterval(transitionInterval);
        transitionPaused = true;
    });
    
    galeriaSection.addEventListener('mouseleave', () => {
        if (transitionPaused) {
            startTransition();
            transitionPaused = false;
        }
    });
    
    // Iniciar transición
    startTransition();
});