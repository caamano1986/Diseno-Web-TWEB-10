document.addEventListener('DOMContentLoaded', function() {
  // Get references to the toggle button and navigation menu
  const mobileToggle = document.querySelector('.header__mobile-toggle');
  const navMenu = document.querySelector('.header__nav');
  
  // Add click event listener to the toggle button
  mobileToggle.addEventListener('click', function() {
    // Toggle active class on navigation menu
    navMenu.classList.toggle('active');
    // Toggle active class on the toggle button itself
    mobileToggle.classList.toggle('active');
    document.body.classList.toggle('menu-open'); // Previene scroll mientras el menú está abierto
  });
  
  // Close menu when clicking on menu items
  const navLinks = document.querySelectorAll('.header__nav a');
  navLinks.forEach(link => {
    link.addEventListener('click', function() {
      navMenu.classList.remove('active');
      mobileToggle.classList.remove('active');
      document.body.classList.remove('menu-open');
    });
  });
  
  // Highlight active section in navigation
  // Get all sections that need to be observed
  const sections = document.querySelectorAll('section[id]');
  
  // Set up the Intersection Observer
  const observerOptions = {
    root: null, // Use the viewport as the root
    rootMargin: '-20% 0px -80% 0px', // Consider sections in the middle of the viewport
    threshold: 0 // Trigger as soon as the section is visible
  };
  
  // Actualización del observer para incluir también los puntos de navegación
  const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
      const id = entry.target.getAttribute('id');
      if (entry.isIntersecting) {
        // Remove active class from all navigation items
        document.querySelectorAll('.header__nav ul li a').forEach(navLink => {
          navLink.classList.remove('active');
        });
        
        // Remove active class from all dot navigation items
        document.querySelectorAll('.nav-dot').forEach(dot => {
          dot.classList.remove('active');
        });
        
        // Add active class to current section's navigation items
        const currentNavItem = document.querySelector(`.header__nav ul li a[href="#${id}"]`);
        const currentDotItem = document.querySelector(`.nav-dot[href="#${id}"]`);
        
        if (currentNavItem) {
          currentNavItem.classList.add('active');
        }
        
        if (currentDotItem) {
          currentDotItem.classList.add('active');
        }
      }
    });
  }, observerOptions);
  
  // Start observing each section
  sections.forEach(section => {
    observer.observe(section);
  });

  // Get all dropdown elements
  const dropdowns = document.querySelectorAll('.dropdown');
  
  // Add click event to each dropdown for mobile
  dropdowns.forEach(dropdown => {
    const dropdownLink = dropdown.querySelector('a');
    
    dropdownLink.addEventListener('click', function(e) {
      // Only handle as dropdown on mobile
      if (window.innerWidth <= 768) {
        e.preventDefault();
        dropdown.classList.toggle('active');
      }
    });
  });

  // Close menu when resize to desktop
  window.addEventListener('resize', function() {
    if (window.innerWidth > 768 && navMenu.classList.contains('active')) {
      navMenu.classList.remove('active');
      mobileToggle.classList.remove('active');
      document.body.classList.remove('menu-open');
    }
  });
});

// Smooth scroll handling for navigation links
document.querySelectorAll('.header__nav ul li a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    
    const targetId = this.getAttribute('href');
    const targetElement = document.querySelector(targetId);
    
    if (targetElement) {
      // Close mobile menu if open
      const mobileNav = document.querySelector('.header__nav');
      const mobileToggle = document.querySelector('.header__mobile-toggle');
      if (mobileNav.classList.contains('active')) {
        mobileNav.classList.remove('active');
        mobileToggle.classList.remove('active');
        document.body.classList.remove('menu-open');
      }
      
      // Scroll to the target
      window.scrollTo({
        top: targetElement.offsetTop - 80, // Adjust offset as needed
        behavior: 'smooth'
      });
    }
  });
});

// Aplicar smooth scroll también a los puntos de navegación
document.querySelectorAll('.nav-dot').forEach(dot => {
  dot.addEventListener('click', function(e) {
    e.preventDefault();
    const targetId = this.getAttribute('href');
    const targetElement = document.querySelector(targetId);
    
    if (targetElement) {
      window.scrollTo({
        top: targetElement.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  });
});